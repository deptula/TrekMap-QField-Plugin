import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var rasterLayers: []

    function refreshLayers() {
        var layers = qgisProject.mapLayers()
        var found = []
        for (var id in layers) {
            var layer = layers[id]
            if (layer && layer.type === 1) found.push(layer)
        }
        rasterLayers = found
    }

    function setVisible(layer, visible) {
        var node = qgisProject.layerTreeRoot().findLayer(layer.id)
        if (node) {
            node.setItemVisibilityChecked(visible)
            mapCanvas.mapSettings.refresh()
        }
    }

    QfToolButton {
        id: button
        round: true
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        bgcolor: Theme.toolButtonBackgroundColor
        onClicked: { refreshLayers(); dialog.open() }
    }

    Dialog {
        id: dialog
        parent: mainWindow.contentItem
        title: "TrekMap"
        modal: false
        width: Math.min(mainWindow.width - 24, 520)
        height: Math.min(mainWindow.height - 48, 600)
        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 12
            spacing: 8
            Label { text: "TrekMap — mapy TrekBuddy"; font.bold: true; font.pixelSize: 20 }
            Label { text: "Plugin działa. Wersja testowa wykrywa rastry obecne w projekcie."; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Button { text: "Odśwież listę"; onClicked: refreshLayers() }
            ListView {
                id: list
                Layout.fillWidth: true; Layout.fillHeight: true; clip: true
                model: rasterLayers
                delegate: RowLayout {
                    width: list.width; height: 54
                    CheckBox {
                        checked: { var n = qgisProject.layerTreeRoot().findLayer(modelData.id); return n ? n.itemVisibilityChecked : false }
                        onClicked: setVisible(modelData, checked)
                    }
                    Label { text: modelData.name; Layout.fillWidth: true; elide: Text.ElideRight }
                }
            }
            Label { visible: list.count === 0; text: "Brak rasterów w projekcie."; opacity: 0.7 }
            Button { Layout.fillWidth: true; text: "Zamknij"; onClicked: dialog.close() }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(button)
        refreshLayers()
    }
}
