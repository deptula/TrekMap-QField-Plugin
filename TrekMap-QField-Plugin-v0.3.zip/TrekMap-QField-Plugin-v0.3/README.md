# TrekMap v0.3

Test plugin QField. Poprawiono import modułu QField: `org.qfield`.
