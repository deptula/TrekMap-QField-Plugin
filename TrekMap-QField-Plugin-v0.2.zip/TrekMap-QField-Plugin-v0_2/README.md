# TrekMap QField Plugin v0.2

Pierwszy testowy plugin do QField.

- dodaje przycisk TrekMap do paska pluginów,
- wykrywa rastry już obecne w projekcie,
- pozwala je włączać/wyłączać,
- nie dodaje rasterów podczas uruchamiania projektu.

Następny etap: dynamiczne wykrywanie katalogu atlasów i dodawanie wybranej mapy TrekBuddy/GeoTIFF/MBTiles dopiero po wyborze użytkownika.
