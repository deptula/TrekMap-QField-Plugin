import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield.org
import org.qfield.gui
import Theme

Item {
    id: plugin
    objectName: "trekMapPlugin"
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var rasterLayers: []

    function refreshLayers() {
        var layers = qgisProject.mapLayers()
        var found = []
        for (var id in layers) {
            var layer = layers[id]
            if (layer && layer.type === 1) found.push(layer)
        }
        rasterLayers = found
    }
    function layerVisible(layer) {
        var node = qgisProject.layerTreeRoot().findLayer(layer.id)
        return node ? node.itemVisibilityChecked : false
    }
    function setVisible(layer, visible) {
        var node = qgisProject.layerTreeRoot().findLayer(layer.id)
        if (node) {
            node.setItemVisibilityChecked(visible)
            mapCanvas.mapSettings.refresh()
        }
    }
    function setAll(visible) {
        for (var i = 0; i < rasterLayers.length; i++) setVisible(rasterLayers[i], visible)
    }

    QfToolButton {
        id: toolButton
        objectName: "trekMapToolButton"
        round: true
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        bgcolor: Theme.toolButtonBackgroundColor
        onClicked: { refreshLayers(); dialog.open() }
    }

    Dialog {
        id: dialog
        objectName: "trekMapDialog"
        parent: mainWindow.contentItem
        title: "TrekMap — mapy TrekBuddy"
        modal: false
        width: Math.min(mainWindow.width - 24, 520)
        height: Math.min(mainWindow.height - 48, 620)

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 12
            spacing: 8
            Label { text: "TrekMap"; font.bold: true; font.pixelSize: 20 }
            Label {
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
                text: "Wersja testowa. Plugin nie ładuje map przy starcie projektu. Pokazuje tylko rastry już dodane do projektu."
                color: Theme.secondaryTextColor
            }
            RowLayout {
                Layout.fillWidth: true
                Button { text: "Odśwież"; onClicked: refreshLayers() }
                Button { text: "Włącz wszystkie"; onClicked: setAll(true) }
                Button { text: "Wyłącz wszystkie"; onClicked: setAll(false) }
            }
            ListView {
                id: rasterList
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 4
                model: rasterLayers
                delegate: Rectangle {
                    width: rasterList.width
                    height: 60
                    color: "transparent"
                    RowLayout {
                        anchors.fill: parent
                        spacing: 8
                        CheckBox {
                            checked: layerVisible(modelData)
                            onClicked: setVisible(modelData, checked)
                        }
                        ColumnLayout {
                            Layout.fillWidth: true
                            Label { text: modelData.name; Layout.fillWidth: true; elide: Text.ElideRight; color: Theme.mainTextColor }
                            Label { text: modelData.source; Layout.fillWidth: true; elide: Text.ElideMiddle; font.pixelSize: 10; color: Theme.secondaryTextColor }
                        }
                    }
                }
                Label { anchors.centerIn: parent; visible: rasterList.count === 0; text: "Brak rasterów w projekcie."; color: Theme.secondaryTextColor }
            }
            Button { Layout.fillWidth: true; text: "Zamknij"; onClicked: dialog.close() }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(toolButton)
        refreshLayers()
        mainWindow.displayToast("TrekMap v0.2 załadowany")
    }
}
