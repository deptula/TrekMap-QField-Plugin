# TrekMap QField Plugin v0.5

Test panel using QField's QfDialog. The plugin does not load rasters automatically.
