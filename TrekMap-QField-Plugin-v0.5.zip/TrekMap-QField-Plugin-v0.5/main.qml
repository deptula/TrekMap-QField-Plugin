import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var rasterLayers: []

    function refreshLayers() {
        var layers = qgisProject.mapLayers()
        var found = []
        for (var id in layers) {
            var layer = layers[id]
            if (layer && layer.type === 1) found.push(layer)
        }
        rasterLayers = found
    }

    function setVisible(layer, visible) {
        var node = qgisProject.layerTreeRoot().findLayer(layer.id)
        if (node) {
            node.setItemVisibilityChecked(visible)
            mapCanvas.mapSettings.refresh()
        }
    }

    QfToolButton {
        id: mapButton
        objectName: "trekMapButton"
        round: true
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        bgcolor: Theme.toolButtonBackgroundColor
        onClicked: {
            refreshLayers()
            trekDialog.open()
        }
    }

    QfDialog {
        id: trekDialog
        objectName: "trekMapDialog"
        parent: mainWindow.contentItem
        title: "TrekMap — mapy TrekBuddy"
        modal: true
        width: Math.min(parent.width - 30, 520)
        height: Math.min(parent.height - 50, 620)
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2
        standardButtons: Dialog.Close

        ColumnLayout {
            width: parent.width
            spacing: 10

            Label {
                text: "TrekMap"
                font.bold: true
                font.pixelSize: 20
            }

            Label {
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
                text: "Panel testowy. Rastry nie są ładowane automatycznie. Lista pokazuje rastry obecne w projekcie."
            }

            RowLayout {
                Layout.fillWidth: true
                Button { text: "Odśwież"; onClicked: refreshLayers() }
                Button {
                    text: "Wyłącz wszystkie"
                    onClicked: {
                        for (var i=0; i<rasterLayers.length; i++) setVisible(rasterLayers[i], false)
                    }
                }
            }

            ListView {
                id: rasterList
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: rasterLayers
                delegate: RowLayout {
                    width: rasterList.width
                    height: 52
                    CheckBox {
                        checked: {
                            var n = qgisProject.layerTreeRoot().findLayer(modelData.id)
                            return n ? n.itemVisibilityChecked : false
                        }
                        onClicked: setVisible(modelData, checked)
                    }
                    Label {
                        text: modelData.name
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                    }
                }
            }

            Label {
                visible: rasterList.count === 0
                text: "Brak rasterów w projekcie."
                opacity: 0.7
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(mapButton)
        refreshLayers()
        mainWindow.displayToast("TrekMap działa")
    }
}
