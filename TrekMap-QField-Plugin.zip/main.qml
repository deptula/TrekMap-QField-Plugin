import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield.org
import org.qfield.gui

Item {
    id: trekMap
    objectName: "trekMap"

    QfToolButton {
        id: trekButton
        iconSource: Theme.getThemeVectorIcon("ic_map_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: trekDialog.open()
    }

    QfDialog {
        id: trekDialog
        objectName: "trekMapDialog"
        parent: iface.mainWindow().contentItem
        width: Math.min(420, iface.mainWindow().width - 32)
        height: Math.min(520, iface.mainWindow().height - 32)
        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2
        title: "TREKMAP"

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 12

            Label { text: "Atlas"; font.bold: true }
            ComboBox {
                id: atlasBox
                Layout.fillWidth: true
                model: ["Karkonosze", "Góry Izerskie", "Rudawy Janowickie", "Sudety"]
            }

            Label { text: "Skala"; font.bold: true }
            ComboBox {
                id: scaleBox
                Layout.fillWidth: true
                model: ["1:17 500", "1:25 000", "1:35 000"]
            }

            Label { text: "Mapa"; font.bold: true }
            ComboBox {
                id: mapBox
                Layout.fillWidth: true
                model: ["E1", "E2", "W1", "W2", "W3", "W4", "W5"]
            }

            Button {
                Layout.fillWidth: true
                text: "WCZYTAJ"
                onClicked: {
                    current.text = "Wybrano: " + atlasBox.currentText + " / " + scaleBox.currentText + " / " + mapBox.currentText
                    trekDialog.close()
                    iface.mainWindow().displayToast("TrekMap: " + current.text)
                }
            }

            Label {
                id: current
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
                text: "Aktualna mapa: brak"
            }

            Item { Layout.fillHeight: true }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(trekButton)
    }
}
