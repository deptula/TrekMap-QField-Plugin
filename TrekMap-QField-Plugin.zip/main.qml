import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qfield.gui

Item {
    id: root
    property var iface: qgis ? qgis : null

    QfToolButton {
        id: button
        objectName: "trekMapButton"
        iconSource: "icon.svg"
        onClicked: panel.open()
    }

    Component.onCompleted: {
        if (iface && iface.addItemToPluginsToolbar)
            iface.addItemToPluginsToolbar(button)
    }

    Popup {
        id: panel
        width: 360
        height: 430
        modal: false
        focus: true
        anchors.centerIn: Overlay.overlay

        background: Rectangle {
            color: "#202124"
            radius: 10
            border.color: "#555555"
            border.width: 1
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 12

            Label {
                text: "TREKMAP"
                font.pixelSize: 24
                font.bold: true
                color: "white"
                Layout.alignment: Qt.AlignHCenter
            }

            Label { text: "Atlas"; color: "white" }
            ComboBox {
                id: atlas
                Layout.fillWidth: true
                model: ["Karkonosze", "Góry Izerskie", "Rudawy Janowickie", "Sudety"]
            }

            Label { text: "Skala"; color: "white" }
            ComboBox {
                id: scale
                Layout.fillWidth: true
                model: ["1:17 500", "1:25 000", "1:35 000"]
                currentIndex: 1
            }

            Label { text: "Mapa"; color: "white" }
            ComboBox {
                id: sheet
                Layout.fillWidth: true
                model: ["E1", "E2", "W1", "W2", "W3", "W4", "W5"]
            }

            Button {
                text: "WCZYTAJ"
                Layout.fillWidth: true
                onClicked: status.text = atlas.currentText + " / " + scale.currentText + " / " + sheet.currentText
            }

            Label {
                id: status
                text: "Aktualna mapa: brak"
                color: "#dddddd"
                wrapMode: Text.WordWrap
                Layout.fillWidth: true
            }

            Item { Layout.fillHeight: true }
        }
    }
}
