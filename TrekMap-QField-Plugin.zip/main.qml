import QtQuick
import QtQuick.Controls
import org.qfield

Item {
    id: root
    QfToolButton {
        id: button
        iconSource: Qt.resolvedUrl("icon.svg")
        onClicked: iface.mainWindow().displayToast("TrekMap działa")
    }
    Component.onCompleted: iface.addItemToPluginsToolbar(button)
}
