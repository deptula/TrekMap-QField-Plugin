import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: plugin

    QfToolButton {
        id: trekButton
        iconSource: Theme.getThemeVectorIcon("ic_map_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: {
            trekDialog.open()
        }
    }

    QfDialog {
        id: trekDialog
        parent: iface.mainWindow().contentItem
        width: Math.min(420, iface.mainWindow().width - 40)
        height: 300
        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2
        title: "TREKMAP"

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 12

            Label { text: "Atlas"; font.bold: true }
            ComboBox {
                id: atlas
                Layout.fillWidth: true
                model: ["Karkonosze", "Góry Izerskie", "Rudawy Janowickie", "Sudety"]
            }

            Label { text: "Skala"; font.bold: true }
            ComboBox {
                id: scale
                Layout.fillWidth: true
                model: ["1:17 500", "1:25 000", "1:35 000"]
            }

            Label { text: "Mapa"; font.bold: true }
            ComboBox {
                id: map
                Layout.fillWidth: true
                model: ["E1", "E2", "W1", "W2", "W3", "W4", "W5"]
            }

            Button {
                Layout.fillWidth: true
                text: "WCZYTAJ"
                onClicked: {
                    iface.mainWindow().displayToast(
                        "TREKMAP: " + atlas.currentText + " / " +
                        scale.currentText + " / " + map.currentText
                    )
                    trekDialog.close()
                }
            }

            Label {
                text: "Aktualna mapa: brak"
                Layout.fillWidth: true
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(trekButton)
    }
}
