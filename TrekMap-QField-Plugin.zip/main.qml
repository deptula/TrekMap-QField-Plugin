import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: root
    width: 1
    height: 1

    QfToolButton {
        id: button
        iconSource: "icon.svg"
        onClicked: dialog.open()
    }

    QfDialog {
        id: dialog
        title: "TREKMAP"
        width: Math.min(420, parent.width * 0.9)
        height: Math.min(520, parent.height * 0.8)
        parent: iface.mainWindow().contentItem

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 14

            Label { text: "Atlas"; font.bold: true }
            ComboBox { Layout.fillWidth: true; model: ["Karkonosze", "Góry Izerskie", "Rudawy Janowickie", "Sudety"] }

            Label { text: "Skala"; font.bold: true }
            ComboBox { Layout.fillWidth: true; model: ["1:17 500", "1:25 000", "1:35 000"] }

            Label { text: "Mapa"; font.bold: true }
            ComboBox { Layout.fillWidth: true; model: ["E1", "E2", "W1", "W2", "W3", "W4", "W5"] }

            Button {
                text: "WCZYTAJ"
                Layout.fillWidth: true
                onClicked: dialog.close()
            }

            Label { text: "Aktualna mapa: brak"; Layout.topMargin: 10 }
        }
    }
}
