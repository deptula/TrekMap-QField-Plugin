import QtQuick
import org.qfield.org
import org.qfield.gui

Item {
  id: trekMap
  objectName: "trekMap"

  QfToolButton {
    id: trekButton
    iconSource: Qt.resolvedUrl("icon.svg")
    iconColor: Theme.toolButtonColor
    bgcolor: Theme.toolButtonBackgroundColor
    round: true

    onClicked: {
      iface.mainWindow().displayToast("TrekMap działa")
    }
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(trekButton)
  }
}
