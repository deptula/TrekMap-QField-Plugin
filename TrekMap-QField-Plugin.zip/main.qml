import QtQuick
import QtQuick.Controls
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: plugin
    objectName: "trekMapPlugin"

    QfToolButton {
        id: trekButton
        iconSource: Theme.getThemeVectorIcon("ic_info_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: iface.mainWindow().displayToast("TrekMap działa")
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(trekButton)
    }
}
