import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield.org
import org.qfield.gui
import Theme

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()

    QfToolButton {
        id: trekButton
        objectName: "trekMapButton"
        round: true
        iconSource: Qt.resolvedUrl("icon.svg")
        iconColor: Theme.mainTextColor
        bgcolor: Theme.toolButtonBackgroundColor

        onClicked: {
            trekDialog.open()
        }
    }

    Dialog {
        id: trekDialog
        objectName: "trekMapDialog"
        parent: mainWindow.contentItem
        visible: false
        modal: true
        title: "TrekMap — mapy TrekBuddy"
        width: Math.min(parent.width - 40, 500)
        height: Math.min(parent.height - 80, 600)
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2

        ColumnLayout {
            width: parent.width
            spacing: 14

            Label {
                text: "TrekMap"
                font: Theme.defaultFont
                font.bold: true
                font.pixelSize: 20
                Layout.fillWidth: true
            }

            Label {
                text: "Panel testowy działa."
                font: Theme.defaultFont
                Layout.fillWidth: true
            }

            GroupBox {
                title: "Atlas"
                Layout.fillWidth: true

                ComboBox {
                    width: parent.width
                    model: ["Karkonosze", "Góry Izerskie", "Rudawy Janowickie", "Sudety"]
                }
            }

            GroupBox {
                title: "Skala"
                Layout.fillWidth: true

                ComboBox {
                    width: parent.width
                    model: ["1:17 500", "1:25 000", "1:35 000"]
                }
            }

            GroupBox {
                title: "Arkusz"
                Layout.fillWidth: true

                ComboBox {
                    width: parent.width
                    model: ["E1", "E2", "W1", "W2", "W3", "W4", "W5"]
                }
            }

            Button {
                text: "TEST — wczytaj mapę"
                Layout.fillWidth: true
                onClicked: {
                    mainWindow.displayToast("TrekMap: przycisk działa")
                }
            }

            Item {
                Layout.fillHeight: true
            }

            Button {
                text: "Zamknij"
                Layout.fillWidth: true
                onClicked: trekDialog.close()
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(trekButton)
    }
}
