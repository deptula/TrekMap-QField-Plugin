import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: root

    QfToolButton {
        id: button
        iconSource: "icon.svg"
        text: "TrekMap"
        onClicked: panel.visible = !panel.visible
    }

    Rectangle {
        id: panel
        visible: false
        width: 320
        height: 300
        anchors.centerIn: parent
        radius: 8
        color: Theme.mainBackgroundColor
        border.color: Theme.mainTextColor
        border.width: 1
        z: 9999

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 12

            Label {
                text: "TREKMAP"
                font.bold: true
                font.pixelSize: 22
                Layout.fillWidth: true
            }

            Label { text: "Atlas" }
            ComboBox {
                Layout.fillWidth: true
                model: ["Karkonosze", "Góry Izerskie", "Rudawy Janowickie", "Sudety"]
            }

            Label { text: "Skala" }
            ComboBox {
                Layout.fillWidth: true
                model: ["1:17 500", "1:25 000", "1:35 000"]
            }

            Label { text: "Mapa" }
            ComboBox {
                Layout.fillWidth: true
                model: ["E1", "E2", "W1", "W2", "W3", "W4", "W5"]
            }

            Button {
                text: "WCZYTAJ"
                Layout.fillWidth: true
            }

            Label {
                text: "Aktualna mapa: brak"
                Layout.fillWidth: true
            }
        }
    }
}
