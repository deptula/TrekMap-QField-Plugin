import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Qt.labs.folderlistmodel
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: trekMapPlugin
    property var mainWindow: iface.mainWindow()
    property string defaultRoot: "file:///storage/emulated/0/TrekBuddy/maps"
    property string selectedRoot: ""
    property var queue: []
    property var foundAtlases: []
    property string currentAtlas: ""
    property bool scanning: false

    function asUrl(v) {
        if (v === undefined || v === null) return ""
        var s = v.toString()
        if (s.length === 0) return ""
        if (s.indexOf("file://") === 0) return s
        return "file://" + s
    }

    function beginScan(path) {
        var u = asUrl(path)
        if (u === "") return
        foundAtlases = []
        queue = [u]
        scanning = true
        scanFolder(u)
    }

    function scanFolder(u) {
        var v = asUrl(u)
        if (v === "") { nextFolder(); return }
        atlasScanner.folder = v
        atlasScanner.active = true
    }

    function nextFolder() {
        if (queue.length === 0) {
            scanning = false
            if (foundAtlases.length > 0) selectAtlas(foundAtlases[0].url)
            return
        }
        var u = queue.shift()
        scanFolder(u)
    }

    function processFolder() {
        var hasAtlas = false
        var dirs = []
        for (var i=0; i<atlasScanner.count; i++) {
            var name = String(atlasScanner.get(i, "fileName"))
            var url = asUrl(atlasScanner.get(i, "fileURL"))
            if (atlasScanner.get(i, "fileIsDir")) dirs.push(url)
            if (name.toLowerCase() === "atlas.tar") hasAtlas = true
        }
        if (hasAtlas) {
            var f = asUrl(atlasScanner.folder)
            if (f !== "" && !foundAtlases.some(function(a) { return a.url === f; })) foundAtlases.push({url: f, name: f.split("/").pop()})
        }
        for (var j=0; j<dirs.length; j++) {
            if (queue.indexOf(dirs[j]) < 0) queue.push(dirs[j])
        }
        atlasScanner.active = false
        nextFolder()
    }

    function selectAtlas(u) {
        var v = asUrl(u)
        if (v === "") return
        currentAtlas = v
        atlasFolderModel.folder = v
        
        levelSelector.currentIndex = -1
        mapSelector.currentIndex = -1
    }

    FolderListModel {
        id: atlasScanner
        showDirs: true
        showFiles: true
        showDotAndDotDot: false
        showHidden: false
        showOnlyReadable: true
        onStatusChanged: if (active && status === FolderListModel.Ready) processFolder()
    }

    FolderListModel {
        id: atlasFolderModel
        showDirs: true
        showFiles: true
        showDotAndDotDot: false
        showHidden: false
        showOnlyReadable: true
    }

    FolderListModel {
        id: mapFileModel
        showDirs: false
        showFiles: true
        showDotAndDotDot: false
        showHidden: false
        showOnlyReadable: true
        nameFilters: ["*.tar", "*.TAR", "*.tmi", "*.TMI"]
    }

    QfToolButton {
        id: trekMapButton
        iconSource: Qt.resolvedUrl("icon.svg")
        iconColor: Theme.mainTextColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        width: 48
        height: 48
        onClicked: trekMapDialog.open()
    }

    QfDialog {
        id: trekMapDialog
        parent: mainWindow.contentItem
        title: "TREKMAP"
        modal: true
        width: Math.min(parent.width - 40, 440)
        height: Math.min(parent.height - 80, 560)

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 10

            Label { text: "TREKMAP — wybór aktualnej mapy"; font.bold: true; Layout.fillWidth: true }

            Button {
                text: "📍  WSKAŻ LOKALIZACJĘ MAP"
                Layout.fillWidth: true
                onClicked: trekFolderDialog.open()
            }

            Button {
                text: "↻  SKANUJ AUTOMATYCZNIE"
                Layout.fillWidth: true
                onClicked: beginScan(defaultRoot)
            }

            Label {
                text: scanning ? "Skanowanie katalogów…" : (foundAtlases.length ? "Znaleziono atlasów: " + foundAtlases.length : "Nie znaleziono ATLAS.TAR")
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
            }

            ComboBox {
                id: atlasSelector
                Layout.fillWidth: true
                model: foundAtlases
                textRole: "name"
                onActivated: if (currentIndex >= 0) selectAtlas(foundAtlases[currentIndex].url)
            }

            Label { text: "Poziom / mapa:"; font.bold: true; Layout.fillWidth: true }

            ComboBox {
                id: levelSelector
                Layout.fillWidth: true
                model: atlasFolderModel
                textRole: "fileName"
                onActivated: {
                    if (currentIndex < 0) return
                    var u = asUrl(atlasFolderModel.get(currentIndex, "fileURL"))
                    if (atlasFolderModel.get(currentIndex, "fileIsDir")) mapFileModel.folder = u
                }
            }

            Label { text: "Plik mapy:"; font.bold: true; Layout.fillWidth: true }

            ComboBox {
                id: mapSelector
                Layout.fillWidth: true
                model: mapFileModel
                textRole: "fileName"
            }

            Button {
                text: "POKAŻ MAPĘ"
                Layout.fillWidth: true
                enabled: mapSelector.currentIndex >= 0
                onClicked: {
                    if (mapSelector.currentIndex >= 0) {
                        var p = String(mapFileModel.get(mapSelector.currentIndex, "filePath"))
                        mainWindow.displayToast("Wybrano: " + p)
                        trekMapDialog.close()
                    }
                }
            }

            Label {
                text: mapSelector.currentIndex >= 0 ? "Aktualna mapa: " + String(mapFileModel.get(mapSelector.currentIndex, "fileName")) : "Aktualna mapa: brak"
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
            }
        }
    }

    FolderDialog {
        id: trekFolderDialog
        title: "Wskaż katalog z mapami TrekBuddy"
        onAccepted: {
            var u = asUrl(selectedFolder)
            if (u !== "") {
                selectedRoot = u
                beginScan(u)
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(trekMapButton)
        beginScan(defaultRoot)
    }
}
