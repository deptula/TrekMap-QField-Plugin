import QtQuick
import QtQuick.Controls
import org.qfield.org
import org.qfield.gui

Item {
    id: plugin
    objectName: "trekMapPlugin"

    QfToolButton {
        id: trekButton
        objectName: "trekMapButton"
        iconSource: Qt.resolvedUrl("icon.svg")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: trekDialog.open()
    }

    Dialog {
        id: trekDialog
        objectName: "trekMapDialog"
        title: "TREKMAP"
        modal: true
        parent: iface.mainWindow().contentItem
        anchors.centerIn: parent
        standardButtons: Dialog.NoButton
        width: Math.min(parent.width - 40, 420)

        Column {
            width: parent.width
            spacing: 12
            padding: 12

            Label { text: "Atlas" }
            ComboBox {
                id: atlasBox
                width: parent.width
                model: ["Karkonosze", "Góry Izerskie", "Rudawy Janowickie", "Sudety"]
            }

            Label { text: "Skala" }
            ComboBox {
                id: scaleBox
                width: parent.width
                model: ["1:17 500", "1:25 000", "1:35 000"]
                currentIndex: 1
            }

            Label { text: "Mapa" }
            ComboBox {
                id: mapBox
                width: parent.width
                model: ["E1", "E2", "W1", "W2", "W3", "W4", "W5"]
            }

            Button {
                text: "WCZYTAJ"
                width: parent.width
                onClicked: {
                    iface.mainWindow().displayToast("Wybrano: " + atlasBox.currentText + " / " + scaleBox.currentText + " / " + mapBox.currentText)
                    trekDialog.close()
                }
            }

            Label {
                text: "Aktualna mapa: brak"
                width: parent.width
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(trekButton)
    }
}
