import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Qt.labs.folderlistmodel
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property string defaultRoot: "file:///storage/emulated/0/TrekBuddy/maps"
    property string selectedRoot: ""
    property var queue: []
    property var foundAtlases: []
    property string currentAtlas: ""
    property bool scanning: false

    function asUrl(v) {
        if (v === undefined || v === null) return ""
        var s = v.toString()
        if (s.length === 0) return ""
        if (s.indexOf("file://") === 0) return s
        return "file://" + s
    }

    function beginScan(path) {
        var u = asUrl(path)
        if (u === "") return
        foundAtlases = []
        queue = [u]
        scanning = true
        scanFolder(u)
    }

    function scanFolder(u) {
        var v = asUrl(u)
        if (v === "") { nextFolder(); return }
        scanner.folder = v
        scanner.active = true
    }

    function nextFolder() {
        if (queue.length === 0) {
            scanning = false
            if (foundAtlases.length > 0) selectAtlas(foundAtlases[0])
            return
        }
        var u = queue.shift()
        scanFolder(u)
    }

    function processFolder() {
        var hasAtlas = false
        var dirs = []
        for (var i=0; i<scanner.count; i++) {
            var name = String(scanner.get(i, "fileName"))
            var url = asUrl(scanner.get(i, "fileURL"))
            if (scanner.get(i, "fileIsDir")) dirs.push(url)
            if (name.toLowerCase() === "atlas.tar") hasAtlas = true
        }
        if (hasAtlas) {
            var f = asUrl(scanner.folder)
            if (f !== "" && foundAtlases.indexOf(f) < 0) foundAtlases.push(f)
        }
        for (var j=0; j<dirs.length; j++) {
            if (queue.indexOf(dirs[j]) < 0) queue.push(dirs[j])
        }
        scanner.active = false
        nextFolder()
    }

    function selectAtlas(u) {
        var v = asUrl(u)
        if (v === "") return
        currentAtlas = v
        atlasContents.folder = v
        mapContents.folder = ""
        layerCombo.currentIndex = -1
        mapCombo.currentIndex = -1
    }

    FolderListModel {
        id: scanner
        showDirs: true
        showFiles: true
        showDotAndDotDot: false
        showHidden: false
        showOnlyReadable: true
        onStatusChanged: if (active && status === FolderListModel.Ready) processFolder()
    }

    FolderListModel {
        id: atlasContents
        showDirs: true
        showFiles: true
        showDotAndDotDot: false
        showHidden: false
        showOnlyReadable: true
    }

    FolderListModel {
        id: mapContents
        showDirs: false
        showFiles: true
        showDotAndDotDot: false
        showHidden: false
        showOnlyReadable: true
        nameFilters: ["*.tar", "*.TAR", "*.tmi", "*.TMI"]
    }

    QfToolButton {
        id: button
        iconSource: Qt.resolvedUrl("icon.svg")
        iconColor: Theme.mainTextColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        width: 48
        height: 48
        onClicked: dialog.open()
    }

    QfDialog {
        id: dialog
        parent: mainWindow.contentItem
        title: "TREKMAP"
        modal: true
        width: Math.min(parent.width - 40, 440)
        height: Math.min(parent.height - 80, 560)

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 10

            Label { text: "TREKMAP — wybór aktualnej mapy"; font.bold: true; Layout.fillWidth: true }

            Button {
                text: "📍  WSKAŻ LOKALIZACJĘ MAP"
                Layout.fillWidth: true
                onClicked: folderDialog.open()
            }

            Button {
                text: "↻  SKANUJ AUTOMATYCZNIE"
                Layout.fillWidth: true
                onClicked: beginScan(defaultRoot)
            }

            Label {
                text: scanning ? "Skanowanie katalogów…" : (foundAtlases.length ? "Znaleziono atlasów: " + foundAtlases.length : "Nie znaleziono ATLAS.TAR")
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
            }

            ComboBox {
                id: atlasCombo
                Layout.fillWidth: true
                model: foundAtlases
                textRole: "fileName"
                onActivated: if (currentIndex >= 0) selectAtlas(foundAtlases[currentIndex])
            }

            Label { text: "Poziom / mapa:"; font.bold: true; Layout.fillWidth: true }

            ComboBox {
                id: layerCombo
                Layout.fillWidth: true
                model: atlasContents
                textRole: "fileName"
                onActivated: {
                    if (currentIndex < 0) return
                    var u = asUrl(atlasContents.get(currentIndex, "fileURL"))
                    if (atlasContents.get(currentIndex, "fileIsDir")) mapContents.folder = u
                }
            }

            Label { text: "Plik mapy:"; font.bold: true; Layout.fillWidth: true }

            ComboBox {
                id: mapCombo
                Layout.fillWidth: true
                model: mapContents
                textRole: "fileName"
            }

            Button {
                text: "POKAŻ MAPĘ"
                Layout.fillWidth: true
                enabled: mapCombo.currentIndex >= 0
                onClicked: {
                    if (mapCombo.currentIndex >= 0) {
                        var p = String(mapContents.get(mapCombo.currentIndex, "filePath"))
                        mainWindow.displayToast("Wybrano: " + p)
                        dialog.close()
                    }
                }
            }

            Label {
                text: mapCombo.currentIndex >= 0 ? "Aktualna mapa: " + String(mapContents.get(mapCombo.currentIndex, "fileName")) : "Aktualna mapa: brak"
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
            }
        }
    }

    FolderDialog {
        id: folderDialog
        title: "Wskaż katalog z mapami TrekBuddy"
        onAccepted: {
            var u = asUrl(selectedFolder)
            if (u !== "") {
                selectedRoot = u
                beginScan(u)
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(button)
        beginScan(defaultRoot)
    }
}
