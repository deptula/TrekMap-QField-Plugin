import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()

    QfToolButton {
        id: trekMapButton
        iconSource: Qt.resolvedUrl("icon.svg")
        iconColor: Theme.mainTextColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        width: 48
        height: 48
        onClicked: dialog.open()
    }

    QfDialog {
        id: dialog
        parent: mainWindow.contentItem
        title: "TREKMAP"
        modal: true
        width: Math.min(parent.width - 40, 420)
        height: Math.min(parent.height - 80, 520)
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 14

            Label { text: "Atlas"; font.bold: true }
            ComboBox {
                id: atlas
                Layout.fillWidth: true
                model: ["Karkonosze", "Góry Izerskie", "Rudawy Janowickie", "Sudety"]
            }

            Label { text: "Skala"; font.bold: true }
            ComboBox {
                id: scale
                Layout.fillWidth: true
                model: ["1:17 500", "1:25 000", "1:35 000"]
            }

            Label { text: "Mapa"; font.bold: true }
            ComboBox {
                id: map
                Layout.fillWidth: true
                model: ["E1", "E2", "W1", "W2", "W3", "W4", "W5"]
            }

            Button {
                text: "WCZYTAJ"
                Layout.fillWidth: true
                onClicked: dialog.close()
            }

            Label {
                text: "Aktualna mapa: brak"
                Layout.topMargin: 10
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(trekMapButton)
    }
}
