# TrekMap QField Plugin v0.4

Test interfejsu TrekMap. Plugin nie ładuje ciężkich map przy starcie. Pokazuje rastry już znajdujące się w projekcie i pozwala nimi sterować.

Następny etap: dynamiczne dodawanie wybranej mapy z katalogu atlasów.
