import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var rasterLayers: []

    function refreshLayers() {
        var layers = qgisProject.mapLayers()
        var found = []
        for (var id in layers) {
            var layer = layers[id]
            if (layer && layer.type === 1)
                found.push(layer)
        }
        rasterLayers = found
    }

    function setVisible(layer, visible) {
        var node = qgisProject.layerTreeRoot().findLayer(layer.id)
        if (node) {
            node.setItemVisibilityChecked(visible)
            mapCanvas.mapSettings.refresh()
        }
    }

    QfToolButton {
        id: button
        round: true
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        bgcolor: Theme.toolButtonBackgroundColor
        onClicked: {
            refreshLayers()
            dialog.open()
        }
    }

    Dialog {
        id: dialog
        parent: mainWindow.contentItem
        title: "TrekMap"
        modal: false
        width: Math.min(mainWindow.width - 24, 540)
        height: Math.min(mainWindow.height - 48, 650)

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 12
            spacing: 10

            Label { text: "TREKMAP"; font.bold: true; font.pixelSize: 22 }
            Label {
                text: "Mapy TrekBuddy — wersja testowa"
                color: Theme.secondaryTextColor
            }

            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: Theme.mainColor
                opacity: 0.35
            }

            Label { text: "Rastry aktualnie dostępne w projekcie"; font.bold: true }

            RowLayout {
                Layout.fillWidth: true
                Button { text: "Odśwież"; onClicked: refreshLayers() }
                Button {
                    text: "Wyłącz wszystkie"
                    onClicked: {
                        for (var i=0; i<rasterLayers.length; i++) setVisible(rasterLayers[i], false)
                    }
                }
            }

            ListView {
                id: list
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: rasterLayers

                delegate: Rectangle {
                    width: list.width
                    height: 64
                    color: "transparent"

                    RowLayout {
                        anchors.fill: parent
                        spacing: 8

                        CheckBox {
                            checked: {
                                var n = qgisProject.layerTreeRoot().findLayer(modelData.id)
                                return n ? n.itemVisibilityChecked : false
                            }
                            onClicked: setVisible(modelData, checked)
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            Label {
                                text: modelData.name
                                Layout.fillWidth: true
                                elide: Text.ElideRight
                            }
                            Label {
                                text: modelData.source
                                Layout.fillWidth: true
                                elide: Text.ElideMiddle
                                font.pixelSize: 10
                                color: Theme.secondaryTextColor
                            }
                        }
                    }
                }

                Label {
                    anchors.centerIn: parent
                    visible: list.count === 0
                    text: "Brak rasterów."
                    color: Theme.secondaryTextColor
                }
            }

            Button {
                Layout.fillWidth: true
                text: "Zamknij"
                onClicked: dialog.close()
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(button)
        refreshLayers()
        iface.logMessage("TrekMap v0.4 uruchomiony")
    }
}
