# TrekMap v0.6
Test panel without QGIS project/layer API calls. This isolates UI/plugin loading before dynamic raster loading is added.
