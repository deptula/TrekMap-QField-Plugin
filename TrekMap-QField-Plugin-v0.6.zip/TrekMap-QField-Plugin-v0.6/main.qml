import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qfield.gui
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()

    QfToolButton {
        id: button
        round: true
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        bgcolor: Theme.toolButtonBackgroundColor
        onClicked: panel.open()
    }

    QfDialog {
        id: panel
        title: "TrekMap"
        width: Math.min(plugin.mainWindow.width - 32, 520)
        height: Math.min(plugin.mainWindow.height - 64, 600)

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 12

            Label {
                text: "TrekMap — mapy TrekBuddy"
                font.pixelSize: 20
                font.bold: true
                Layout.fillWidth: true
            }

            Label {
                text: "Panel działa. Następny krok: katalog atlasów i dynamiczne dodawanie map."
                wrapMode: Text.WordWrap
                Layout.fillWidth: true
            }

            GroupBox {
                title: "Atlas"
                Layout.fillWidth: true
                ColumnLayout {
                    anchors.fill: parent
                    ComboBox {
                        id: atlas
                        Layout.fillWidth: true
                        model: ["Karkonosze", "Góry Izerskie", "Rudawy Janowickie", "Sudety"]
                    }
                }
            }

            GroupBox {
                title: "Skala"
                Layout.fillWidth: true
                ColumnLayout {
                    anchors.fill: parent
                    ComboBox {
                        id: scale
                        Layout.fillWidth: true
                        model: ["1:17 500", "1:25 000", "1:35 000"]
                    }
                }
            }

            GroupBox {
                title: "Mapa"
                Layout.fillWidth: true
                ColumnLayout {
                    anchors.fill: parent
                    ComboBox {
                        id: sheet
                        Layout.fillWidth: true
                        model: ["E1", "E2", "W1", "W2", "W3", "W4", "W5"]
                    }
                }
            }

            Button {
                text: "Wczytaj mapę"
                Layout.fillWidth: true
                onClicked: mainWindow.displayToast("Wybrano: " + atlas.currentText + " / " + scale.currentText + " / " + sheet.currentText)
            }

            Item { Layout.fillHeight: true }

            Button {
                text: "Zamknij"
                Layout.fillWidth: true
                onClicked: panel.close()
            }
        }
    }

    Component.onCompleted: iface.addItemToPluginsToolbar(button)
}
